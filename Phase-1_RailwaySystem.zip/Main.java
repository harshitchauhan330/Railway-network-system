import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        RailwaySystem railwaySystem = RailwaySystem.loadState();

        // Read entire input from System.in
        Scanner scanner = new Scanner(System.in);
        StringBuilder input = new StringBuilder();
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.trim().isEmpty()) {
                // Process a command block when a blank line is encountered
                if (input.length() > 0) {
                    String result = railwaySystem.processCommand(input.toString().trim());
                    System.out.println(result);
                    input.setLength(0); // Clear the buffer
                }
            } else {
                input.append(line).append("\n");
            }
        }

        // Process any remaining command block
        if (input.length() > 0) {
            String result = railwaySystem.processCommand(input.toString().trim());
            System.out.println(result);
        }

        railwaySystem.saveState();
    }
}
