import java.io.Serializable;

public class Line implements Serializable {
    private String name;
    private String[] stations;
    private int stationCount;

    public Line(String name) {
        this.name = name;
        this.stations = new String[500]; // Assuming max stations
        this.stationCount = 0;
    }

    public void addStation(String stationName) {
        stations[stationCount++] = stationName;
    }

    public String listStations() {
        StringBuilder result = new StringBuilder(name + "\n");
        for (int i = 0; i < stationCount; i++) {
            result.append(stations[i]).append("\n");
        }
        return result.toString();
    }
}
