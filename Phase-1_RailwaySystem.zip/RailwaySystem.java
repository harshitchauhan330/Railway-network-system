import java.io.*;

public class RailwaySystem implements Serializable {
    private KeyValueStore lines; // Custom key-value store for lines

    public RailwaySystem() {
        this.lines = new KeyValueStore();
    }

    public String processCommand(String command) {

        // Trim input and check the first word for the operation type
        String[] lines = command.split("\n");
        String[] parts = lines[0].trim().split(" ");
        String operation = parts[0].trim();

        try {
            switch (operation) {
                case "IL": // Insert Line
                    return insertLine(lines);
                case "CL": // List Stations of a Line
                    return listStations(parts[1].trim());
                case "RL": // Remove Line
                    return removeLine(parts[1].trim());
                default:
                    return "Invalid command.";
            }
        } catch (Exception e) {
            return "Error processing command: " + e.getMessage();
        }
    }

    private String insertLine(String[] commandLines) {
        // Extract line name and station names
        String lineName = commandLines[0].split(" ")[1].trim();

        Line newLine = new Line(lineName);

        // Add stations
        for (int i = 1; i < commandLines.length; i++) {
            String stationName = commandLines[i].trim();
            if (!stationName.isEmpty()) {
                newLine.addStation(stationName);
            }
        }

        // Check if line already exists
        if (lines.containsKey(lineName.toLowerCase())) {
            return "Linha existente.";
        }

        // Add the line to the system
        lines.put(lineName.toLowerCase(), newLine);
        return "Inserção de linha com sucesso.";
    }

    private String removeLine(String lineName) {
        if (!lines.containsKey(lineName.toLowerCase())) {
            return "Linha inexistente.";
        }
        lines.remove(lineName.toLowerCase());
        return "Remoção de linha com sucesso.";
    }

    private String listStations(String lineName) {
        Line line = (Line) lines.get(lineName.toLowerCase());
        if (line == null) {
            return "Linha inexistente.";
        }
        return line.listStations();
    }

    // Persistence methods
    public void saveState() throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("state.dat"))) {
            out.writeObject(this);
        }
    }

    public static RailwaySystem loadState() throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("state.dat"))) {
            return (RailwaySystem) in.readObject();
        } catch (FileNotFoundException e) {
            return new RailwaySystem();
        }
    }
}
