Railway Network Support System
Phase 1 – README

Project Overview
This project implements a Railway Network Support System using custom data structures, adhering to Version I requirements (no use of java.util classes except Scanner). The system supports operations like adding/removing railway lines, managing train schedules, and querying data, with persistent storage for state management.

File Descriptions
1. Main.java
Role: The entry point of the application.
Key Responsibilities:
Handles input and output through the standard console.
Processes user commands and delegates tasks to the RailwaySystem class.
Manages termination and ensures state persistence by invoking save and load methods.
2. RailwaySystem.java
Role: The core of the system, responsible for managing all railway data.
Key Responsibilities:
Maintains a collection of Line objects using a custom dictionary (KeyValueStore).
Implements logic for operations like:
Adding and removing lines.
Querying stations and schedules.
Handles persistence by serializing and deserializing the system state.
Data Structure Used:
KeyValueStore to manage railway lines.
3. KeyValueStore.java
Role: A custom implementation of a key-value store, replacing HashMap.
Key Responsibilities:
Provides efficient storage and retrieval of key-value pairs.
Includes methods for:
Adding a new key-value pair.
Retrieving a value by key.
Checking for key existence.
4. Line.java
Role: Represents a railway line.
Key Responsibilities:
Stores the line name and associated stations in a custom list (CustomArrayList).
Provides methods to:
Add, remove, and query stations.
Validate line data (e.g., no duplicate stations).
Supports operations needed by the RailwaySystem class.
5. Schedule.java
Role: A placeholder class for Phase 2 features related to train schedules.
Key Responsibilities (for Phase 1):
Defines the structure for storing schedules (line name, train number, timetable).
Ensures that timetables follow the required formatting and order.
6. Persistence.java
Role: Handles state saving and loading via Java serialization.
Key Responsibilities:
Saves the current state of the system to a file (state.dat) when the application terminates.
Loads the previous state on startup, ensuring continuity between sessions.
Integrated into the RailwaySystem class for simplicity.
Instructions for Running the Program
Compilation:
Use the following command to compile all .java files:

bash
Copy code
javac *.java
Execution:
Run the program using:

bash
Copy code
java Main
Input Format:

Input commands must strictly follow the syntax outlined in the project handout (e.g., IL line-name ↰ station1 ↰ ... stationN ↰ ↰).
Commands are case-insensitive.
Saving and Loading State:

The program automatically saves its state to state.dat upon termination (TA command).
On startup, the program attempts to load the previous state from state.dat.
Phase 1 Features
Implemented Commands
Insert Line (IL line-name ↰ station1 ↰ ... stationN ↰ ↰):
Adds a new railway line with the specified stations.

Remove Line (RL line-name):
Removes an existing railway line.

List Stations of a Line (CL line-name):
Displays the list of stations for a given line in insertion order.

Insert Schedule (IH line-name ↰ train-number ↰ station1 time1 ↰ ... stationN timeN ↰ ↰):
Defines a schedule for a train on a specific line (basic validation for Phase 1).

Remove Schedule (RH line-name ↰ station-name time):
Removes a train schedule based on its departure time.

Phase 2 Preparation
Schedule.java has been designed to accommodate advanced features like timetable validation, ensuring no train overtakes or simultaneous departures.
Custom data structures (CustomArrayList, CustomDictionary) are optimized to handle increased data volume and complexity.
Notes
This implementation strictly adheres to Version I requirements, avoiding the use of java.util classes beyond Scanner.
The project structure allows easy extension for Phase 2 features.