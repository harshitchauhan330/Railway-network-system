package main.dataStructures;

/**
 * Iterator for the HashTable class.
 * 
 * @author Gustavo Chevrand (64616) g.chevrand@campus.fct.unl.pt
 * @author Rildo Franco (64605) rw.franco@campus.fct.unl.pt
 */
public class HashTableIterator<K, V> implements Iterator<Entry<K, V>> {
    private Dictionary<K, V>[] table;
    private int currentList;
    private Iterator<Entry<K, V>> currentIterator;

    public HashTableIterator(Dictionary<K, V>[] table) {
        this.table = table;
        rewind();
    }

    public void rewind() {
        currentList = -1;
        searchNext();
    }

    public Entry<K, V> next() {
        if (!hasNext())
            throw new NoSuchElementException();

        Entry<K, V> entry = currentIterator.next();

        if (!currentIterator.hasNext())
            searchNext();

        return entry;
    }

    public boolean hasNext() {
        return currentIterator != null && currentIterator.hasNext();
    }

    private void searchNext() {
        do {
            currentList++;
        } while (currentList < table.length && table[currentList].isEmpty());

        if (currentList < table.length)
            currentIterator = table[currentList].iterator();
    }
}