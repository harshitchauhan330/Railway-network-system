package main.dataStructures;

import java.io.Serializable;

/**
 * Comparator interface
 * 
 * @param <E> Generic Element
 */
public interface Comparator<E> extends Serializable {
	int compare(E o1, E o2);
}
