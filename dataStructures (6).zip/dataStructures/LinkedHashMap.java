package main.dataStructures;

/**
 * Linked Hash Map implementation
 * 
 * Maintains a linked list of entries in the order in which they were inserted
 * 
 * @param <K> Generic Key, must extend comparable
 * @param <V> Generic Value
 */
public class LinkedHashMap<K extends Comparable<K>, V> extends HashTable<K, V> {
	static class LinkedHashMapEntry<K extends Comparable<K>, V> extends EntryClass<K, V> {
		private LinkedHashMapEntry<K, V> previous;

		private LinkedHashMapEntry<K, V> next;

		public LinkedHashMapEntry(K key, V value) {
			super(key, value);
		}

		public LinkedHashMapEntry<K, V> getPrevious() {
			return previous;
		}

		public void setPrevious(LinkedHashMapEntry<K, V> previous) {
			this.previous = previous;
		}

		public LinkedHashMapEntry<K, V> getNext() {
			return next;
		}

		public void setNext(LinkedHashMapEntry<K, V> next) {
			this.next = next;
		}
	}

	private Dictionary<K, LinkedHashMapEntry<K, V>> table;
	private LinkedHashMapEntry<K, V> firstEntry;
	private LinkedHashMapEntry<K, V> lastEntry;

	public LinkedHashMap(int capacity) {
		super();

		this.table = new SepChainHashTable<>(capacity);
	}

	public LinkedHashMap() {
		this(DEFAULT_CAPACITY);
	}

	@Override
	public V insert(K key, V value) {
		LinkedHashMapEntry<K, V> val = this.table.find(key);

		if (val == null) {
			val = new LinkedHashMapEntry<>(key, value);

			this.table.insert(key, val);

			if (this.firstEntry == null) {
				this.firstEntry = val;
				this.lastEntry = val;
			} else {
				this.lastEntry.setNext(val);
				val.setPrevious(this.lastEntry);
				this.lastEntry = val;
			}

			currentSize++;
		} else {
			val.setValue(value);
		}

		return val.getValue();
	}

	@Override
	public V find(K key) {
		LinkedHashMapEntry<K, V> val = this.table.find(key);

		if (val == null)
			return null;

		return val.getValue();
	}

	@Override
	public V remove(K key) {
		LinkedHashMapEntry<K, V> val = this.table.remove(key);

		if (val == null)
			return null;

		if (val.getPrevious() != null)
			val.getPrevious().setNext(val.getNext());
		if (val.getNext() != null)
			val.getNext().setPrevious(val.getPrevious());

		if (val == this.firstEntry)
			this.firstEntry = val.getNext();

		currentSize--;

		return val.getValue();
	}

	@Override
	public Iterator<Entry<K, V>> iterator() {
		return new LinkedHashMapIterator<>(this.firstEntry, this.lastEntry);
	}

}
