package main.dataStructures;

/**
 * Iterator for the BST in key order.
 * 
 */
public class BSTKeyOrderIterator<K, V> implements Iterator<Entry<K, V>> {
    private Stack<BSTNode<K, V>> steps;
    private BSTNode<K, V> root;

    BSTKeyOrderIterator(BSTNode<K, V> root) {
        this.root = root;
        rewind();
    }

    @Override
    public boolean hasNext() {
        return !steps.isEmpty();
    }

    @Override
    public Entry<K, V> next() throws NoSuchElementException {
        if (!hasNext())
            throw new NoSuchElementException();

        BSTNode<K, V> next = steps.pop();

        if (next.getRight() != null) {
            steps.push(next.getRight());

            while (steps.top().getLeft() != null)
                steps.push(steps.top().getLeft());
        }

        return next.getEntry();
    }

    @Override
    public void rewind() {
        steps = new StackInList<BSTNode<K, V>>();

        if (root != null) {
            steps.push(root);

            while (steps.top().getLeft() != null)
                steps.push(steps.top().getLeft());
        }
    }

}
