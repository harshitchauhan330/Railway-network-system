package main.dataStructures;

import main.dataStructures.LinkedHashMap.LinkedHashMapEntry;

/**
 * Linked Hash Map Two Way Iterator implementation
 * 
 */
public class LinkedHashMapIterator<K extends Comparable<K>, V> implements TwoWayIterator<Entry<K, V>> {
	private LinkedHashMapEntry<K, V> firstEntry;
	private LinkedHashMapEntry<K, V> lastEntry;
	private LinkedHashMapEntry<K, V> currentEntry;

	public LinkedHashMapIterator(LinkedHashMapEntry<K, V> firstEntry, LinkedHashMapEntry<K, V> lastEntry) {
		this.firstEntry = firstEntry;
		this.currentEntry = firstEntry;
		this.lastEntry = lastEntry;
	}

	@Override
	public boolean hasNext() {
		return currentEntry != null;
	}

	@Override
	public boolean hasPrevious() {
		return currentEntry != null;
	}

	@Override
	public Entry<K, V> next() throws NoSuchElementException {
		if (!hasNext())
			throw new NoSuchElementException();

		LinkedHashMapEntry<K, V> entry = currentEntry;
		currentEntry = currentEntry.getNext();

		return entry;
	}

	@Override
	public void rewind() {
		currentEntry = firstEntry;
	}

	@Override
	public void fullForward() {
		currentEntry = lastEntry;
	}

	@Override
	public Entry<K, V> previous() throws NoSuchElementException {
		if (!hasPrevious())
			throw new NoSuchElementException();

		LinkedHashMapEntry<K, V> entry = currentEntry;

		currentEntry = currentEntry.getPrevious();

		return entry;
	}

}
